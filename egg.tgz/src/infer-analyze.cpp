// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("infer analyze"); }
int main(){
  announce();
  return lionss_run_workload("infer-analyze");
}
