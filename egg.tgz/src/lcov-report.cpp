// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("lcov report"); }
int main(){
  announce();
  return lionss_run_workload("lcov-report");
}
