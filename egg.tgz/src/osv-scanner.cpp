// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("osv scanner"); }
int main(){
  announce();
  return lionss_run_workload("osv-scanner");
}
