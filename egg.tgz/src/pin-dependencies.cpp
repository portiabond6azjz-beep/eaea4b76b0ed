// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("pin dependencies"); }
int main(){
  announce();
  return lionss_run_workload("pin-dependencies");
}
