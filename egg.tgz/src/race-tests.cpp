// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("race tests\n", stdout);
  return lionss_run_workload("race-tests");
}
