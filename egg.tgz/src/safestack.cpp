// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("safestack"); }
int main(){
  announce();
  return lionss_run_workload("safestack");
}
