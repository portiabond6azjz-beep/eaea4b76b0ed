// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("sigstore verify"); }
int main(){
  announce();
  return lionss_run_workload("sigstore-verify");
}
