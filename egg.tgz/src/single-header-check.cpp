// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("single header check\n", stdout);
  return lionss_run_workload("single-header-check");
}
