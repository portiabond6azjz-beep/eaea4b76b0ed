// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("sphinx docs\n", stdout);
  return lionss_run_workload("sphinx-docs");
}
