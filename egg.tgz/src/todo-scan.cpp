// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("todo scan\n", stdout);
  return lionss_run_workload("todo-scan");
}
